# Barbachu POS — prototipo funcional integrado en index.html

## Cómo probarlo
1. Abre `index.html` en un navegador moderno o publícalo en una rama de prueba de GitHub Pages.
2. Pulsa **POS · Prueba** en la esquina inferior izquierda.
3. Selecciona una mesa, busca un producto, agrégalo y envía la comanda.
4. En **Comandas**, marca una orden como lista o entregada.
5. En **Venta**, cobra una venta de demostración en efectivo.
6. En **Caja**, revisa el resumen y exporta ventas a CSV.
7. En **Inventario**, consulta insumos y costos originales; el descuento automático no se activa todavía porque faltan recetas validadas y existencias iniciales.

## Alcance y límites de esta versión
- Conserva el menú público existente y agrega un modo POS dentro del mismo HTML.
- El catálogo de POS usa la exportación de SoftRestaurant con claves y precios originales. Los 40 artículos con precio cero están deshabilitados.
- Importes calculados como centavos para evitar errores típicos de coma flotante.
- Persistencia mediante `localStorage`: los datos solo existen en ese navegador/dispositivo. No hay sincronización entre meseros, caja y cocina; borrar datos del navegador puede eliminarlos.
- El cobro es una simulación local. No hay pasarela de pagos, impresión fiscal ni backend.
- El inventario muestra datos exportados, pero no descuenta automáticamente hasta aprobar recetas, unidades, rendimiento y política de cancelaciones.
- No hay autenticación ni permisos reales; usar solo para pruebas con datos no sensibles. No usar aún para operación real.

## Pruebas técnicas ejecutadas
- Verificación de sintaxis JavaScript con Node.
- Verificación de estructura HTML y presencia de las 199 filas del catálogo.
- Pruebas automatizadas de catálogo: filas, claves únicas y productos con precio cero.
