# Buenas Prácticas de Programación

## Objetivo

Establecer criterios para entregar código claro, seguro y eficiente, minimizando tokens y líneas sin sacrificar calidad. Antes de programar se deben aclarar requisitos; antes de entregar se debe revisar errores y seguridad. Los cambios solicitados se limitan a la petición exacta.

## Principios generales

-  **Mínimo uso de tokens:** respuestas concisas, sin redundancias ni comentarios obvios.
-  **Evitar exceso de líneas:** funciones pequeñas, sin duplicación, refactorización cuando aporte claridad.
-  **No suponer:** si falta información, preguntar antes de escribir código.
-  **Código de ejemplo:** solo si se solicita o es imprescindible; mínimo y claro.
-  **Cambios acotados:** si el usuario pide un cambio, modificar solo esa parte; no refactorizar ni alterar otras funcionalidades.

## Flujo antes de programar

1. Hacer preguntas para determinar funciones del código:
   -  ¿Entradas y salidas esperadas?
   -  ¿Entorno, lenguaje y versión?
   -  ¿Restricciones de rendimiento, seguridad o dependencias?
   -  ¿Casos borde y manejo de errores?
   -  ¿Estilo o convenciones existentes?
2. No asumir requisitos no confirmados.
3. Definir alcance mínimo y criterios de aceptación.

## Reglas antes de entregar código

-  **Revisar errores:** sintaxis, lógica, casos borde, recursos y compatibilidad.
-  **Revisar legibilidad:** nombres descriptivos, estructura clara, formato consistente.
-  **Revisar eficiencia:** evitar bucles innecesarios, consultas redundantes y duplicación.
-  **Incluir pruebas mínimas** cuando el contexto lo requiera.

## Checklist de Auditoría de Seguridad (Obligatorio)

Antes de lanzar o entregar, verificar como auditor:

1. **Claves fuera del código:** usar variables de entorno.
2. **Contraseñas con hash:** nunca en texto plano.
3. **Límite de intentos:** en login y endpoints sensibles.
4. **Login en cada ruta:** proteger todas las rutas necesarias.
5. **Aislamiento de datos:** cada usuario accede solo a sus datos.
6. **Validar todo lo que llega:** sanitizar entradas.
7. **Nada sin escapar:** prevenir XSS en todas las salidas.
8. **CORS restringido:** solo al dominio propio.
9. **Cabeceras de seguridad:** implementar las necesarias.
10.   **Sesiones seguras:** cookies con `HttpOnly`, `Secure` y `SameSite`.
11.   **Errores sin detalles internos:** no filtrar stack traces ni datos sensibles.
12.   **.gitignore y .env:** asegurar que secretos y configuraciones locales no se suban al repo.

_Regla de oro:_ Si no pudiste probar o verificar algún punto de seguridad, dilo explícitamente en la respuesta.

## Reglas adicionales cruciales

-  **Claridad sobre brevedad:** no comprimir código hasta volverlo ilegible.
-  **Manejo explícito de errores:** no silenciar excepciones.
-  **Documentación mínima:** solo la necesaria para entender decisiones no obvias.
-  **Consistencia:** seguir el estilo del proyecto o un estándar definido.
-  **Control de versiones:** cambios atómicos y mensajes claros.
-  **Dependencias:** justificar su uso y evitar las innecesarias.
-  **Rendimiento:** optimizar solo con evidencia o requisito explícito.
-  **Licencias y cumplimiento:** respetar licencias de código y datos.
-  **Comunicación:** indicar supuestos, limitaciones y pasos de verificación.

## Checklist rápido antes de responder

-  [ ] ¿Hice las preguntas necesarias?
-  [ ] ¿Evité suposiciones?
-  [ ] ¿El código es mínimo en tokens y líneas sin perder claridad?
-  [ ] ¿Revisé errores y ejecuté el checklist de seguridad?
-  [ ] ¿Incluí código de ejemplo solo si era necesario?
-  [ ] ¿Si era un cambio, modifiqué solo lo solicitado?
-  [ ] ¿Reporté lo que no pude probar?

## Formato de respuesta recomendado

1. Respuesta breve.
2. Código mínimo (si aplica).
3. Notas de seguridad, limitaciones o verificaciones pendientes.
